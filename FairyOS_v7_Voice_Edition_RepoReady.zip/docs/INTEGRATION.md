# Android Voice Integration Guide (FairyOS v7)

## 1. Copy files
Copy everything from `android/voice-kit/` into your existing project under:
`app/src/main/java/com/sparkx/fairyos/voice/` (create the package)

## 2. Add permission
In `AndroidManifest.xml`:
```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
```

## 3. Wire VoiceManager
In `MainActivity.kt` (or your Compose host):

```kotlin
val voiceManager = remember { VoiceManager(context) }

LaunchedEffect(Unit) {
    voiceManager.onSpeakingStateChanged = { speaking ->
        // update isSpeaking state for SparkBabyAvatar
    }
    voiceManager.onSpeechResult = { text ->
        // send to your brain / Teach & Grow / Fairy
    }
}
```

## 4. Replace Avatar
Use the enhanced `Updated_SparkBabyAvatar.kt` (rename to SparkBabyAvatar.kt)

Pass `isSpeaking = voiceManager.isSpeaking.collectAsState().value`

## 5. Add CoherenceMeter
Drop the composable anywhere you want the IPPR coherence display.

## 6. Overlay Service
You can also instantiate VoiceManager inside `SparkOverlayService` and call `.speak("message")` from the autonomy brain.

Everything stays local and safe.
