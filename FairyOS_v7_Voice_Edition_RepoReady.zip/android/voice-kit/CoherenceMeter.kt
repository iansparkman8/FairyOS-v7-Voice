package com.sparkx.fairyos.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sparkx.fairyos.domain.SparkColors

/**
 * Beautiful holographic coherence meter for Spark Baby / IPPR integration.
 * Shows current coherence level (0-100) with smooth animation and mood-reactive color.
 */
@Composable
fun CoherenceMeter(
    coherence: Float,           // 0f - 100f
    modifier: Modifier = Modifier,
    label: String = "COHERENCE",
    showLabel: Boolean = true
) {
    val animatedCoherence by animateFloatAsState(
        targetValue = coherence.coerceIn(0f, 100f),
        animationSpec = tween(durationMillis = 650, easing = androidx.compose.animation.core.EaseOutCubic),
        label = "CoherenceAnim"
    )

    val progress = animatedCoherence / 100f

    // Mood-reactive color
    val meterColor = when {
        animatedCoherence > 85f -> SparkColors.VibrantMagenta
        animatedCoherence > 65f -> SparkColors.GoldEnergy
        animatedCoherence > 40f -> SparkColors.NeonCyan
        else -> SparkColors.GlowPurple
    }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (showLabel) {
            Text(
                text = label,
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
        }

        Box(
            modifier = Modifier.size(92.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokeWidth = 9.dp.toPx()
                val radius = (size.minDimension - strokeWidth) / 2f
                val center = Offset(size.width / 2f, size.height / 2f)

                // Background track
                drawCircle(
                    color = Color.White.copy(alpha = 0.08f),
                    radius = radius,
                    center = center,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )

                // Progress arc
                val sweep = 270f * progress
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            meterColor.copy(alpha = 0.3f),
                            meterColor,
                            meterColor.copy(alpha = 0.85f)
                        )
                    ),
                    startAngle = 135f,
                    sweepAngle = sweep,
                    useCenter = false,
                    topLeft = Offset(center.x - radius, center.y - radius),
                    size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2),
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )

                // Inner glow dot at current progress
                val angleRad = Math.toRadians((135f + sweep - 90f).toDouble())
                val dotX = center.x + radius * kotlin.math.cos(angleRad).toFloat()
                val dotY = center.y + radius * kotlin.math.sin(angleRad).toFloat()

                drawCircle(
                    color = meterColor.copy(alpha = 0.6f),
                    radius = 7f,
                    center = Offset(dotX, dotY)
                )
                drawCircle(
                    color = Color.White,
                    radius = 3.5f,
                    center = Offset(dotX, dotY)
                )
            }

            // Center number
            Text(
                text = "${animatedCoherence.toInt()}",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}