package com.sparkx.fairyos.ui.components

import androidx.compose.animation.core.EaseInOutQuad
import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.dp
import com.sparkx.fairyos.domain.FairyMood
import com.sparkx.fairyos.domain.SparkColors
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Enhanced SparkBabyAvatar with stronger reactivity to voice states.
 * - isSpeaking: mouth opens wider + rhythmic pulse, stronger core glow, energetic particles
 * - isListening: attentive wide eyes + gentle mouth "O", focused particles
 */
@Composable
fun SparkBabyAvatar(
    mood: FairyMood,
    modifier: Modifier = Modifier,
    isSpeaking: Boolean = false,
    isThinking: Boolean = false,
    isListening: Boolean = false
) {
    val transition = rememberInfiniteTransition(label = "SparkBabyAvatar")

    // Base wing flap (slightly faster/more energetic when speaking)
    val wingFlapSpeed = if (isSpeaking) 420 else 560
    val wingFlap by transition.animateFloat(
        initialValue = 0.72f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(wingFlapSpeed, easing = EaseInOutQuad),
            repeatMode = RepeatMode.Reverse
        ),
        label = "WingFlap"
    )

    // Core pulse - much stronger and rhythmic when speaking
    val corePulseSpeed = if (isSpeaking) 650 else if (isListening) 1100 else 1500
    val corePulse by transition.animateFloat(
        initialValue = if (isSpeaking) 0.78f else 0.84f,
        targetValue = if (isSpeaking) 1.35f else 1.14f,
        animationSpec = infiniteRepeatable(
            animation = tween(corePulseSpeed, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "CorePulse"
    )

    val bobbing by transition.animateFloat(
        initialValue = -0.018f,
        targetValue = 0.018f,
        animationSpec = infiniteRepeatable(
            animation = tween(3200, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Bobbing"
    )

    val orbitRotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isSpeaking) 4200 else 7000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "OrbitRotation"
    )

    // Blink - slower/more thoughtful when listening, quick when speaking
    val blinkDuration = if (isListening) 9200 else if (isSpeaking) 4200 else 7600
    val blinkScale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = blinkDuration
                1f at 0
                1f at (blinkDuration - 400)
                0.08f at (blinkDuration - 250)
                1f at blinkDuration
            }
        ),
        label = "Blink"
    )

    val baseMoodColor = when (mood) {
        FairyMood.IDLE -> SparkColors.NeonCyan
        FairyMood.HAPPY -> SparkColors.VibrantMagenta
        FairyMood.THINKING -> SparkColors.GlowPurple
        FairyMood.LISTENING -> SparkColors.NeonCyan
        FairyMood.ALERT -> SparkColors.GoldEnergy
        FairyMood.SLEEPY -> SparkColors.SoftLavender
    }

    // Voice-reactive color shift
    val effectiveColor = when {
        isSpeaking -> SparkColors.VibrantMagenta
        isListening -> SparkColors.NeonCyan
        else -> baseMoodColor
    }

    val leftWingPath = remember { Path() }
    val rightWingPath = remember { Path() }
    val torsoPath = remember { Path() }
    val crownPath = remember { Path() }
    val mouthPath = remember { Path() }

    Canvas(modifier = modifier.defaultMinSize(minWidth = 64.dp, minHeight = 64.dp)) {
        if (size.width <= 1f || size.height <= 1f) return@Canvas

        val minSide = min(size.width, size.height)
        val cx = size.width * 0.50f
        val cy = size.height * (0.53f + bobbing)
        val headRadius = minSide * 0.18f
        val headCenterY = cy - minSide * 0.14f
        val bodyTopY = headCenterY + headRadius * 0.82f
        val bodyBottomY = cy + minSide * 0.28f
        val strokeThin = minSide * 0.009f
        val strokeMedium = minSide * 0.014f

        // Background glow - stronger when speaking
        val glowAlpha = if (isSpeaking) 0.38f else if (isListening) 0.26f else 0.22f
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(effectiveColor.copy(alpha = glowAlpha * corePulse), Color.Transparent),
                center = Offset(cx, cy),
                radius = minSide * 0.50f
            ),
            radius = minSide * 0.50f,
            center = Offset(cx, cy)
        )

        // Wings (withTransform for flapping)
        withTransform({
            scale(scaleX = wingFlap, scaleY = 1.0f, pivot = Offset(cx - minSide * 0.06f, bodyTopY))
        }) {
            leftWingPath.reset()
            leftWingPath.moveTo(cx - minSide * 0.035f, bodyTopY)
            leftWingPath.cubicTo(
                cx - minSide * 0.38f,
                bodyTopY - minSide * 0.34f,
                cx - minSide * 0.58f,
                bodyTopY + minSide * 0.04f,
                cx - minSide * 0.055f,
                bodyTopY + minSide * 0.31f
            )
            leftWingPath.cubicTo(
                cx - minSide * 0.23f,
                bodyTopY + minSide * 0.08f,
                cx - minSide * 0.14f,
                bodyTopY - minSide * 0.02f,
                cx - minSide * 0.035f,
                bodyTopY
            )
            leftWingPath.close()
            drawPath(
                path = leftWingPath,
                brush = Brush.linearGradient(listOf(effectiveColor.copy(alpha = 0.95f), SparkColors.GlowPurple.copy(alpha = 0.16f), Color.Transparent)),
                style = Stroke(width = strokeMedium)
            )
            drawPath(
                path = leftWingPath,
                brush = Brush.radialGradient(listOf(effectiveColor.copy(alpha = 0.14f), Color.Transparent))
            )
            for (i in 1..5) {
                val t = i / 6f
                drawLine(
                    color = effectiveColor.copy(alpha = 0.18f),
                    start = Offset(cx - minSide * 0.045f, bodyTopY + minSide * 0.02f),
                    end = Offset(cx - minSide * (0.16f + t * 0.24f), bodyTopY - minSide * 0.15f + minSide * t * 0.36f),
                    strokeWidth = strokeThin
                )
            }
        }

        withTransform({
            scale(scaleX = wingFlap, scaleY = 1.0f, pivot = Offset(cx + minSide * 0.06f, bodyTopY))
        }) {
            rightWingPath.reset()
            rightWingPath.moveTo(cx + minSide * 0.035f, bodyTopY)
            rightWingPath.cubicTo(
                cx + minSide * 0.38f,
                bodyTopY - minSide * 0.34f,
                cx + minSide * 0.58f,
                bodyTopY + minSide * 0.04f,
                cx + minSide * 0.055f,
                bodyTopY + minSide * 0.31f
            )
            rightWingPath.cubicTo(
                cx + minSide * 0.23f,
                bodyTopY + minSide * 0.08f,
                cx + minSide * 0.14f,
                bodyTopY - minSide * 0.02f,
                cx + minSide * 0.035f,
                bodyTopY
            )
            rightWingPath.close()
            drawPath(
                path = rightWingPath,
                brush = Brush.linearGradient(listOf(effectiveColor.copy(alpha = 0.95f), SparkColors.GlowPurple.copy(alpha = 0.16f), Color.Transparent)),
                style = Stroke(width = strokeMedium)
            )
            drawPath(
                path = rightWingPath,
                brush = Brush.radialGradient(listOf(effectiveColor.copy(alpha = 0.14f), Color.Transparent))
            )
            for (i in 1..5) {
                val t = i / 6f
                drawLine(
                    color = effectiveColor.copy(alpha = 0.18f),
                    start = Offset(cx + minSide * 0.045f, bodyTopY + minSide * 0.02f),
                    end = Offset(cx + minSide * (0.16f + t * 0.24f), bodyTopY - minSide * 0.15f + minSide * t * 0.36f),
                    strokeWidth = strokeThin
                )
            }
        }

        // Torso
        torsoPath.reset()
        torsoPath.moveTo(cx, bodyTopY)
        torsoPath.cubicTo(cx - minSide * 0.13f, bodyTopY + minSide * 0.12f, cx - minSide * 0.13f, bodyBottomY - minSide * 0.05f, cx, bodyBottomY)
        torsoPath.cubicTo(cx + minSide * 0.13f, bodyBottomY - minSide * 0.05f, cx + minSide * 0.13f, bodyTopY + minSide * 0.12f, cx, bodyTopY)
        drawPath(
            path = torsoPath,
            brush = Brush.verticalGradient(listOf(Color.White, effectiveColor.copy(alpha = 0.36f), SparkColors.GlowPurple.copy(alpha = 0.22f)))
        )
        drawCircle(
            brush = Brush.radialGradient(listOf(Color.White, effectiveColor.copy(alpha = 0.72f * corePulse), Color.Transparent)),
            radius = minSide * 0.088f * corePulse,
            center = Offset(cx, bodyTopY + minSide * 0.11f)
        )

        // Head
        drawCircle(
            brush = Brush.verticalGradient(listOf(Color.White, effectiveColor.copy(alpha = 0.20f))),
            radius = headRadius,
            center = Offset(cx, headCenterY)
        )

        // Eyes - more expressive with voice states
        val eyeScale = when {
            isSpeaking -> 1.08f
            isListening -> 1.22f   // Wide attentive eyes
            mood == FairyMood.SLEEPY -> 0.22f
            mood == FairyMood.HAPPY -> 1.24f
            mood == FairyMood.THINKING -> 0.78f
            mood == FairyMood.ALERT -> 1.18f
            else -> blinkScale
        }
        val eyeSpacing = headRadius * 0.43f
        val eyeY = headCenterY + headRadius * 0.10f
        val eyeRadius = headRadius * 0.21f
        val eyeHighlight = headRadius * 0.075f

        withTransform({ scale(scaleX = 1f, scaleY = eyeScale, pivot = Offset(cx - eyeSpacing, eyeY)) }) {
            drawCircle(color = effectiveColor, radius = eyeRadius, center = Offset(cx - eyeSpacing, eyeY))
            drawCircle(color = Color.White, radius = eyeHighlight, center = Offset(cx - eyeSpacing - eyeRadius * 0.28f, eyeY - eyeRadius * 0.34f))
        }
        withTransform({ scale(scaleX = 1f, scaleY = eyeScale, pivot = Offset(cx + eyeSpacing, eyeY)) }) {
            drawCircle(color = effectiveColor, radius = eyeRadius, center = Offset(cx + eyeSpacing, eyeY))
            drawCircle(color = Color.White, radius = eyeHighlight, center = Offset(cx + eyeSpacing - eyeRadius * 0.28f, eyeY - eyeRadius * 0.34f))
        }

        // Mouth - voice reactive
        val mouthY = headCenterY + headRadius * 0.46f
        when {
            isSpeaking -> {
                // Open animated mouth for speaking
                drawCircle(
                    color = effectiveColor.copy(alpha = 0.92f),
                    radius = headRadius * (0.13f + 0.04f * corePulse),
                    center = Offset(cx, mouthY),
                    style = Stroke(width = strokeThin * 1.5f)
                )
                // Inner mouth
                drawCircle(
                    color = Color(0xFF2A0A2A).copy(alpha = 0.6f),
                    radius = headRadius * (0.07f + 0.03f * corePulse),
                    center = Offset(cx, mouthY)
                )
            }
            isListening -> {
                // Gentle listening "O" mouth
                drawCircle(
                    color = effectiveColor.copy(alpha = 0.88f),
                    radius = headRadius * 0.09f,
                    center = Offset(cx, mouthY),
                    style = Stroke(width = strokeThin)
                )
            }
            else -> {
                // Default gentle smile
                mouthPath.reset()
                mouthPath.moveTo(cx - headRadius * 0.22f, mouthY)
                mouthPath.quadraticBezierTo(cx, mouthY + headRadius * 0.16f, cx + headRadius * 0.22f, mouthY)
                drawPath(
                    path = mouthPath,
                    color = effectiveColor.copy(alpha = 0.78f),
                    style = Stroke(width = strokeThin)
                )
            }
        }

        // Crown
        val crownBaseY = headCenterY - headRadius * 0.92f
        crownPath.reset()
        crownPath.moveTo(cx, crownBaseY - minSide * 0.10f * corePulse)
        crownPath.lineTo(cx - minSide * 0.045f, crownBaseY - minSide * 0.015f)
        crownPath.lineTo(cx, crownBaseY + minSide * 0.015f)
        crownPath.lineTo(cx + minSide * 0.045f, crownBaseY - minSide * 0.015f)
        crownPath.close()
        crownPath.moveTo(cx - minSide * 0.055f, crownBaseY)
        crownPath.lineTo(cx - minSide * 0.115f, crownBaseY - minSide * 0.065f * corePulse)
        crownPath.lineTo(cx - minSide * 0.078f, crownBaseY + minSide * 0.026f)
        crownPath.close()
        crownPath.moveTo(cx + minSide * 0.055f, crownBaseY)
        crownPath.lineTo(cx + minSide * 0.115f, crownBaseY - minSide * 0.065f * corePulse)
        crownPath.lineTo(cx + minSide * 0.078f, crownBaseY + minSide * 0.026f)
        crownPath.close()
        drawPath(crownPath, brush = Brush.verticalGradient(listOf(Color.White, SparkColors.GoldEnergy)))
        drawPath(crownPath, color = SparkColors.NeonCyan.copy(alpha = 0.65f), style = Stroke(width = strokeThin))

        // Orbiting particles - more and brighter when speaking
        val maxRadius = minSide * 0.42f
        val (particleColor, particleCount, opacity) = when {
            isSpeaking -> Triple(SparkColors.VibrantMagenta, 9, 0.98f)
            isListening -> Triple(SparkColors.NeonCyan, 7, 0.92f)
            mood == FairyMood.HAPPY -> Triple(SparkColors.VibrantMagenta, 7, 0.95f)
            mood == FairyMood.THINKING -> Triple(SparkColors.GlowPurple, 5, 0.80f)
            mood == FairyMood.ALERT -> Triple(SparkColors.GoldEnergy, 8, 0.95f)
            mood == FairyMood.SLEEPY -> Triple(SparkColors.SoftLavender, 3, 0.35f)
            else -> Triple(SparkColors.NeonCyan, 4, 0.65f)
        }
        val baseAngleRad = Math.toRadians(orbitRotation.toDouble())
        for (i in 0 until particleCount) {
            val angle = baseAngleRad + i * (2.0 * Math.PI / particleCount)
            val orbitY = if (mood == FairyMood.THINKING || isThinking) 0.32f else 0.64f
            val pX = cx + (maxRadius * cos(angle)).toFloat()
            val pY = cy + (maxRadius * sin(angle)).toFloat() * orbitY
            val pRadius = if (i % 2 == 0) minSide * 0.012f else minSide * 0.007f
            drawCircle(color = particleColor.copy(alpha = opacity), radius = pRadius, center = Offset(pX, pY))
            if (isSpeaking || mood == FairyMood.HAPPY || mood == FairyMood.ALERT) {
                drawCircle(color = SparkColors.GoldEnergy.copy(alpha = opacity * 0.25f), radius = pRadius * 2.2f, center = Offset(pX, pY))
            }
        }
    }
}