package com.sparkx.fairyos.domain

enum class FairyMood {
    IDLE,
    HAPPY,
    THINKING,
    LISTENING,
    ALERT,
    SLEEPY
}