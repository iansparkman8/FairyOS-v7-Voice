package com.sparkx.fairyos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sparkx.fairyos.domain.FairyMood
import com.sparkx.fairyos.domain.SparkColors
import com.sparkx.fairyos.ui.CoherenceMeter
import com.sparkx.fairyos.ui.SparkBabyAvatar
import com.sparkx.fairyos.voice.VoiceManager
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                SparkBabyVoiceDemo()
            }
        }
    }
}

@Composable
fun SparkBabyVoiceDemo() {
    val context = LocalContext.current
    val voiceManager = remember { VoiceManager(context) }
    val scope = rememberCoroutineScope()

    var isListening by remember { mutableStateOf(false) }
    var isSpeaking by remember { mutableStateOf(false) }
    var lastHeard by remember { mutableStateOf("") }
    var coherence by remember { mutableStateOf(47f) }
    var currentMood by remember { mutableStateOf(FairyMood.IDLE) }

    // Observe voice states
    LaunchedEffect(voiceManager) {
        voiceManager.isListening.collect { listening ->
            isListening = listening
            if (listening) currentMood = FairyMood.LISTENING
        }
    }
    LaunchedEffect(voiceManager) {
        voiceManager.isSpeaking.collect { speaking ->
            isSpeaking = speaking
            if (speaking) currentMood = FairyMood.HAPPY
            else if (!isListening) currentMood = FairyMood.IDLE
        }
    }

    voiceManager.onSpeechResult = { text ->
        lastHeard = text
        coherence = (coherence + 8).coerceAtMost(100f)
        scope.launch {
            // Simple response
            val reply = when {
                text.lowercase().contains("hello") || text.lowercase().contains("hi") -> 
                    "Hello Ian! Coherence is rising."
                text.lowercase().contains("how are you") -> 
                    "I'm feeling very coherent today."
                else -> "I heard you say: $text. That's interesting."
            }
            voiceManager.speak(reply)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SparkColors.DeepVoid)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Spark Baby Voice Demo",
            color = SparkColors.NeonCyan,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            "v7 • Natural Voice + Reactive Avatar",
            color = Color.White.copy(alpha = 0.6f),
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(40.dp))

        // The Avatar
        SparkBabyAvatar(
            mood = currentMood,
            modifier = Modifier.size(220.dp),
            isSpeaking = isSpeaking,
            isListening = isListening
        )

        Spacer(modifier = Modifier.height(30.dp))

        // Coherence Meter
        CoherenceMeter(
            coherence = coherence,
            modifier = Modifier.padding(bottom = 20.dp)
        )

        // Status
        Text(
            when {
                isListening -> "Listening..."
                isSpeaking -> "Speaking..."
                else -> "Tap the buttons below"
            },
            color = when {
                isListening -> SparkColors.NeonCyan
                isSpeaking -> SparkColors.VibrantMagenta
                else -> Color.White.copy(alpha = 0.7f)
            },
            fontSize = 18.sp
        )

        if (lastHeard.isNotBlank()) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                "You said: \"$lastHeard\"",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 14.sp
            )
        }

        Spacer(modifier = Modifier.height(40.dp))

        // Controls
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = {
                    if (isListening) voiceManager.stopListening()
                    else voiceManager.startListening()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isListening) SparkColors.VibrantMagenta else SparkColors.NeonCyan
                ),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
            ) {
                Text(
                    if (isListening) "Stop Listening" else "🎤 Start Listening",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = {
                    voiceManager.speak("Hello Ian. This is Spark Baby speaking with natural voice. Coherence feels good today.")
                    coherence = (coherence + 12).coerceAtMost(100f)
                },
                colors = ButtonDefaults.buttonColors(containerColor = SparkColors.GlowPurple),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
            ) {
                Text("Speak Demo", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedButton(
            onClick = {
                coherence = 35f
                currentMood = FairyMood.IDLE
                lastHeard = ""
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Reset Demo")
        }

        Spacer(modifier = Modifier.weight(1f))

        Text(
            "Everything runs locally on device • No cloud • Privacy first",
            color = Color.White.copy(alpha = 0.4f),
            fontSize = 12.sp
        )
    }
}