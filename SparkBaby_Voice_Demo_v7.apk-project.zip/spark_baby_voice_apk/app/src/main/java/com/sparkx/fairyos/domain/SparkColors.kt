package com.sparkx.fairyos.domain

import androidx.compose.ui.graphics.Color

object SparkColors {
    val DeepVoid = Color(0xFF0A0516)
    val NebulaPurple = Color(0xFF160A2C)
    val GlowPurple = Color(0xFF9D4EDD)
    val NeonCyan = Color(0xFF00F5D4)
    val GoldEnergy = Color(0xFFFFD700)
    val VibrantMagenta = Color(0xFFFF007F)
    val SoftLavender = Color(0xFFD6C4FF)
}